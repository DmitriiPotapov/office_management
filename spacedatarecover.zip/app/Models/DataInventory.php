<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DataInventory extends Model
{
    //
}
