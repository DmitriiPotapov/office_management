<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BaseJobStatuse extends Model
{
    protected $fillable = [
        'status_name'
    ];
}
