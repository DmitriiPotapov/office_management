<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BaseUserGroups extends Model
{
    //
}
