<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BaseRoles extends Model
{
    //
}
