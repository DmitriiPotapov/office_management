<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobPriority extends Model
{
    protected $fillable = [
        'job_priority_name'
    ];
}
